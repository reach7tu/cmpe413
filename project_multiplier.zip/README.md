# 8-bit Multiplier Simulation Guide

## Setup
- Open Cadence Virtuoso
- Load the 'project' library
- Open multiplier_8bit_tb testbench schematic

## Setting Inputs
Each input bit A<0>-A<7> and B<0>-B<7> has its own VDC source.
- Logic 0 = set VDC to 0V
- Logic 1 = set VDC to 1.2V

## Example: A=2, B=2 (expect OUTPUT=4)
- Set A<1> = 1.2V, all other A bits = 0V
- Set B<1> = 1.2V, all other B bits = 0V
- Expected: OUTPUT<2> = 1.2V, all others = 0V

## Example: A=255, B=255 (expect OUTPUT=65025)
- Set all A bits = 1.2V
- Set all B bits = 1.2V
- Expected: OUTPUT<0>=1.2V, OUTPUT<1-8>=0V, OUTPUT<9-15>=1.2V

## Running Simulation
- Open ADE/Maestro
- Run transient simulation for 25ns
- VDD = 1.2V
- Check OUTPUT<15:0> voltage levels in waveform viewer