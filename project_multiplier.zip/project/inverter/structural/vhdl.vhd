-- Created by @(#)$CDS: vhdlin version IC23.1-64b 06/21/2023 09:20 (cpgbld16) $
-- on Fri Apr 24 13:47:38 2026


architecture structural of inverter is

begin

  output <= not (input);

end structural;
