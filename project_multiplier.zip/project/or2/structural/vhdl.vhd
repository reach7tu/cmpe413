-- Created by @(#)$CDS: vhdlin version IC23.1-64b 06/21/2023 09:20 (cpgbld16) $
-- on Fri Apr 24 13:47:38 2026


architecture structural of or2 is

begin

  output <= input2 or input1;

end structural;
