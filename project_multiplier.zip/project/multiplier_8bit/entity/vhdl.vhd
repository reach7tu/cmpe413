-- Created by @(#)$CDS: vhdlin version IC23.1-64b 06/21/2023 09:20 (cpgbld16) $
-- on Mon Apr 27 20:08:17 2026


library STD;
library IEEE;
use IEEE.std_logic_1164.all;

entity multiplier_8bit is
    port (
        A       : in  std_logic_vector(7 downto 0);
        B       : in  std_logic_vector(7 downto 0);
        PRODUCT : out std_logic_vector(15 downto 0)
    );
end multiplier_8bit;
