-- Created by @(#)$CDS: vhdlin version IC23.1-64b 06/21/2023 09:20 (cpgbld16) $
-- on Mon Apr 27 20:08:17 2026


architecture structural of multiplier_8bit is

    -- --------------------------------------------------------
    -- Component declarations
    -- --------------------------------------------------------
    component half_adder
        port (
            a     : in  std_logic;
            b     : in  std_logic;
            sum   : out std_logic;
            carry : out std_logic
        );
    end component;

    component full_adder
        port (
            a    : in  std_logic;
            b    : in  std_logic;
            cin  : in  std_logic;
            sum  : out std_logic;
            cout : out std_logic
        );
    end component;

    -- --------------------------------------------------------
    -- Partial products
    -- pp(i)(j) = B(i) AND A(j)
    -- Row i is the partial product row for bit B(i)
    -- --------------------------------------------------------

    for all : half_adder use entity work.half_adder(structural);
    for all : full_adder use entity work.full_adder(structural);

    type pp_array is array (0 to 7) of std_logic_vector(7 downto 0);
    signal pp : pp_array;

    -- --------------------------------------------------------
    -- Sum and carry wires between adder rows
    -- Row 1 sums (row 0 = raw partial products, no adders yet)
    -- --------------------------------------------------------

    -- After row 1 adders (adding pp(0) and pp(1))
    signal s1 : std_logic_vector(7 downto 0);
    signal c1 : std_logic_vector(7 downto 0);

    -- After row 2 adders (adding s1 and pp(2))
    signal s2 : std_logic_vector(7 downto 0);
    signal c2 : std_logic_vector(7 downto 0);

    -- After row 3 adders (adding s2 and pp(3))
    signal s3 : std_logic_vector(7 downto 0);
    signal c3 : std_logic_vector(7 downto 0);

    -- After row 4 adders (adding s3 and pp(4))
    signal s4 : std_logic_vector(7 downto 0);
    signal c4 : std_logic_vector(7 downto 0);

    -- After row 5 adders (adding s4 and pp(5))
    signal s5 : std_logic_vector(7 downto 0);
    signal c5 : std_logic_vector(7 downto 0);

    -- After row 6 adders (adding s5 and pp(6))
    signal s6 : std_logic_vector(7 downto 0);
    signal c6 : std_logic_vector(7 downto 0);

    -- After row 7 adders (adding s6 and pp(7))
    -- This is the final row, gives us the upper bits of product
    signal s7 : std_logic_vector(7 downto 0);
    signal c7 : std_logic_vector(7 downto 0);

begin

    -- --------------------------------------------------------
    -- Step 1: Generate all partial products
    -- pp(i)(j) = B(i) AND A(j)
    -- --------------------------------------------------------
    gen_pp : for i in 0 to 7 generate
        gen_pp_bits : for j in 0 to 7 generate
            pp(i)(j) <= B(i) and A(j);
        end generate;
    end generate;

    -- --------------------------------------------------------
    -- Step 2: Row 1 - Add pp(0) and pp(1)
    --
    -- pp(0)(0) goes directly to PRODUCT(0), no adder needed.
    --
    -- Column 0: pp(0)(1) + pp(1)(0) -> use half adder
    --   sum  = s1(0)   -> becomes PRODUCT(1) later
    --   carry= c1(0)   -> feeds next column
    --
    -- Columns 1 to 6: pp(0)(col+1) + pp(1)(col) + carry_in -> full adder
    --
    -- Column 7: pp(1)(7) + carry from col 6 -> half adder
    --   (pp(0) only has 8 bits, so pp(0)(8) doesn't exist)
    -- --------------------------------------------------------

    -- PRODUCT bit 0 comes straight from pp(0)(0), no adder
    PRODUCT(0) <= pp(0)(0);

    -- Column 0 of row 1: half adder
    HA_R1_C0 : half_adder
        port map (
            a     => pp(0)(1),
            b     => pp(1)(0),
            sum   => s1(0),
            carry => c1(0)
        );

    -- Columns 1..6 of row 1: full adders
    FA_R1_C1 : full_adder port map (a=>pp(0)(2), b=>pp(1)(1), cin=>c1(0), sum=>s1(1), cout=>c1(1));
    FA_R1_C2 : full_adder port map (a=>pp(0)(3), b=>pp(1)(2), cin=>c1(1), sum=>s1(2), cout=>c1(2));
    FA_R1_C3 : full_adder port map (a=>pp(0)(4), b=>pp(1)(3), cin=>c1(2), sum=>s1(3), cout=>c1(3));
    FA_R1_C4 : full_adder port map (a=>pp(0)(5), b=>pp(1)(4), cin=>c1(3), sum=>s1(4), cout=>c1(4));
    FA_R1_C5 : full_adder port map (a=>pp(0)(6), b=>pp(1)(5), cin=>c1(4), sum=>s1(5), cout=>c1(5));
    FA_R1_C6 : full_adder port map (a=>pp(0)(7), b=>pp(1)(6), cin=>c1(5), sum=>s1(6), cout=>c1(6));

    -- Column 7 of row 1: half adder (no more pp(0) bits)
    HA_R1_C7 : half_adder
        port map (
            a     => pp(1)(7),
            b     => c1(6),
            sum   => s1(7),
            carry => c1(7)
        );

    -- --------------------------------------------------------
    -- Step 3: Row 2 - Add s1 (shifted by 1) and pp(2)
    --
    -- s1(0) goes to PRODUCT(1), no adder needed.
    -- The column positions shift by 1 each row.
    -- --------------------------------------------------------
    PRODUCT(1) <= s1(0);

    HA_R2_C0 : half_adder  port map (a=>s1(1),  b=>pp(2)(0), sum=>s2(0), carry=>c2(0));
    FA_R2_C1 : full_adder  port map (a=>s1(2),  b=>pp(2)(1), cin=>c2(0), sum=>s2(1), cout=>c2(1));
    FA_R2_C2 : full_adder  port map (a=>s1(3),  b=>pp(2)(2), cin=>c2(1), sum=>s2(2), cout=>c2(2));
    FA_R2_C3 : full_adder  port map (a=>s1(4),  b=>pp(2)(3), cin=>c2(2), sum=>s2(3), cout=>c2(3));
    FA_R2_C4 : full_adder  port map (a=>s1(5),  b=>pp(2)(4), cin=>c2(3), sum=>s2(4), cout=>c2(4));
    FA_R2_C5 : full_adder  port map (a=>s1(6),  b=>pp(2)(5), cin=>c2(4), sum=>s2(5), cout=>c2(5));
    FA_R2_C6 : full_adder  port map (a=>s1(7),  b=>pp(2)(6), cin=>c2(5), sum=>s2(6), cout=>c2(6));
    HA_R2_C7 : half_adder  port map (a=>c1(7),  b=>pp(2)(7), sum=>s2(7), carry=>c2(7));

    -- --------------------------------------------------------
    -- Row 3 - Add s2 (shifted by 1) and pp(3)
    -- --------------------------------------------------------
    PRODUCT(2) <= s2(0);

    HA_R3_C0 : half_adder  port map (a=>s2(1),  b=>pp(3)(0), sum=>s3(0), carry=>c3(0));
    FA_R3_C1 : full_adder  port map (a=>s2(2),  b=>pp(3)(1), cin=>c3(0), sum=>s3(1), cout=>c3(1));
    FA_R3_C2 : full_adder  port map (a=>s2(3),  b=>pp(3)(2), cin=>c3(1), sum=>s3(2), cout=>c3(2));
    FA_R3_C3 : full_adder  port map (a=>s2(4),  b=>pp(3)(3), cin=>c3(2), sum=>s3(3), cout=>c3(3));
    FA_R3_C4 : full_adder  port map (a=>s2(5),  b=>pp(3)(4), cin=>c3(3), sum=>s3(4), cout=>c3(4));
    FA_R3_C5 : full_adder  port map (a=>s2(6),  b=>pp(3)(5), cin=>c3(4), sum=>s3(5), cout=>c3(5));
    FA_R3_C6 : full_adder  port map (a=>s2(7),  b=>pp(3)(6), cin=>c3(5), sum=>s3(6), cout=>c3(6));
    FA_R3_C7 : full_adder  port map (a=>c2(7),  b=>pp(3)(7), cin=>c3(6), sum=>s3(7), cout=>c3(7));

    -- --------------------------------------------------------
    -- Row 4 - Add s3 (shifted by 1) and pp(4)
    -- --------------------------------------------------------
    PRODUCT(3) <= s3(0);

    HA_R4_C0 : half_adder  port map (a=>s3(1),  b=>pp(4)(0), sum=>s4(0), carry=>c4(0));
    FA_R4_C1 : full_adder  port map (a=>s3(2),  b=>pp(4)(1), cin=>c4(0), sum=>s4(1), cout=>c4(1));
    FA_R4_C2 : full_adder  port map (a=>s3(3),  b=>pp(4)(2), cin=>c4(1), sum=>s4(2), cout=>c4(2));
    FA_R4_C3 : full_adder  port map (a=>s3(4),  b=>pp(4)(3), cin=>c4(2), sum=>s4(3), cout=>c4(3));
    FA_R4_C4 : full_adder  port map (a=>s3(5),  b=>pp(4)(4), cin=>c4(3), sum=>s4(4), cout=>c4(4));
    FA_R4_C5 : full_adder  port map (a=>s3(6),  b=>pp(4)(5), cin=>c4(4), sum=>s4(5), cout=>c4(5));
    FA_R4_C6 : full_adder  port map (a=>s3(7),  b=>pp(4)(6), cin=>c4(5), sum=>s4(6), cout=>c4(6));
    FA_R4_C7 : full_adder  port map (a=>c3(7),  b=>pp(4)(7), cin=>c4(6), sum=>s4(7), cout=>c4(7));

    -- --------------------------------------------------------
    -- Row 5 - Add s4 (shifted by 1) and pp(5)
    -- --------------------------------------------------------
    PRODUCT(4) <= s4(0);

    HA_R5_C0 : half_adder  port map (a=>s4(1),  b=>pp(5)(0), sum=>s5(0), carry=>c5(0));
    FA_R5_C1 : full_adder  port map (a=>s4(2),  b=>pp(5)(1), cin=>c5(0), sum=>s5(1), cout=>c5(1));
    FA_R5_C2 : full_adder  port map (a=>s4(3),  b=>pp(5)(2), cin=>c5(1), sum=>s5(2), cout=>c5(2));
    FA_R5_C3 : full_adder  port map (a=>s4(4),  b=>pp(5)(3), cin=>c5(2), sum=>s5(3), cout=>c5(3));
    FA_R5_C4 : full_adder  port map (a=>s4(5),  b=>pp(5)(4), cin=>c5(3), sum=>s5(4), cout=>c5(4));
    FA_R5_C5 : full_adder  port map (a=>s4(6),  b=>pp(5)(5), cin=>c5(4), sum=>s5(5), cout=>c5(5));
    FA_R5_C6 : full_adder  port map (a=>s4(7),  b=>pp(5)(6), cin=>c5(5), sum=>s5(6), cout=>c5(6));
    FA_R5_C7 : full_adder  port map (a=>c4(7),  b=>pp(5)(7), cin=>c5(6), sum=>s5(7), cout=>c5(7));

    -- --------------------------------------------------------
    -- Row 6 - Add s5 (shifted by 1) and pp(6)
    -- --------------------------------------------------------
    PRODUCT(5) <= s5(0);

    HA_R6_C0 : half_adder  port map (a=>s5(1),  b=>pp(6)(0), sum=>s6(0), carry=>c6(0));
    FA_R6_C1 : full_adder  port map (a=>s5(2),  b=>pp(6)(1), cin=>c6(0), sum=>s6(1), cout=>c6(1));
    FA_R6_C2 : full_adder  port map (a=>s5(3),  b=>pp(6)(2), cin=>c6(1), sum=>s6(2), cout=>c6(2));
    FA_R6_C3 : full_adder  port map (a=>s5(4),  b=>pp(6)(3), cin=>c6(2), sum=>s6(3), cout=>c6(3));
    FA_R6_C4 : full_adder  port map (a=>s5(5),  b=>pp(6)(4), cin=>c6(3), sum=>s6(4), cout=>c6(4));
    FA_R6_C5 : full_adder  port map (a=>s5(6),  b=>pp(6)(5), cin=>c6(4), sum=>s6(5), cout=>c6(5));
    FA_R6_C6 : full_adder  port map (a=>s5(7),  b=>pp(6)(6), cin=>c6(5), sum=>s6(6), cout=>c6(6));
    FA_R6_C7 : full_adder  port map (a=>c5(7),  b=>pp(6)(7), cin=>c6(6), sum=>s6(7), cout=>c6(7));

    -- --------------------------------------------------------
    -- Row 7 (Final) - Add s6 (shifted by 1) and pp(7)
    -- The sums and carries from this row give the upper bits
    -- of the product.
    -- --------------------------------------------------------
    PRODUCT(6) <= s6(0);

    HA_R7_C0 : half_adder  port map (a=>s6(1),  b=>pp(7)(0), sum=>s7(0), carry=>c7(0));
    FA_R7_C1 : full_adder  port map (a=>s6(2),  b=>pp(7)(1), cin=>c7(0), sum=>s7(1), cout=>c7(1));
    FA_R7_C2 : full_adder  port map (a=>s6(3),  b=>pp(7)(2), cin=>c7(1), sum=>s7(2), cout=>c7(2));
    FA_R7_C3 : full_adder  port map (a=>s6(4),  b=>pp(7)(3), cin=>c7(2), sum=>s7(3), cout=>c7(3));
    FA_R7_C4 : full_adder  port map (a=>s6(5),  b=>pp(7)(4), cin=>c7(3), sum=>s7(4), cout=>c7(4));
    FA_R7_C5 : full_adder  port map (a=>s6(6),  b=>pp(7)(5), cin=>c7(4), sum=>s7(5), cout=>c7(5));
    FA_R7_C6 : full_adder  port map (a=>s6(7),  b=>pp(7)(6), cin=>c7(5), sum=>s7(6), cout=>c7(6));
    FA_R7_C7 : full_adder  port map (a=>c6(7),  b=>pp(7)(7), cin=>c7(6), sum=>s7(7), cout=>c7(7));

    -- --------------------------------------------------------
    -- Connect final row outputs to upper bits of PRODUCT
    -- --------------------------------------------------------
    PRODUCT(7)  <= s7(0);
    PRODUCT(8)  <= s7(1);
    PRODUCT(9)  <= s7(2);
    PRODUCT(10) <= s7(3);
    PRODUCT(11) <= s7(4);
    PRODUCT(12) <= s7(5);
    PRODUCT(13) <= s7(6);
    PRODUCT(14) <= s7(7);
    PRODUCT(15) <= c7(7);

end structural;
