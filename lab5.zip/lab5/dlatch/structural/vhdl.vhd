-- Created by @(#)$CDS: vhdlin version IC23.1-64b 06/21/2023 09:20 (cpgbld16) $
-- on Wed Apr  1 21:09:12 2026


architecture structural of dlatch is
begin
  output: process (d,en)
  begin
    if en = '1' then
      q <= d;
      q_n <= not d ;
    end if;
  end process output;
end structural;
