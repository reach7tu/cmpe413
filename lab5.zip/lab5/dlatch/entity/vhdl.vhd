-- Created by @(#)$CDS: vhdlin version IC23.1-64b 06/21/2023 09:20 (cpgbld16) $
-- on Wed Apr  1 21:09:12 2026


library STD;
library IEEE;
use IEEE.std_logic_1164.all;
entity dlatch is
  port ( d   : in           std_logic;
         en  : in           std_logic;
         q   : out          std_logic;
         q_n : out          std_logic);
end dlatch;
