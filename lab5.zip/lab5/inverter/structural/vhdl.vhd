-- Created by @(#)$CDS: vhdlin version IC23.1-64b 06/21/2023 09:20 (cpgbld16) $
-- on Tue Mar 31 20:55:45 2026


architecture structural of inverter is

begin

  output <= not (output);

end structural;
