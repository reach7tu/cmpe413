-- Created by @(#)$CDS: vhdlin version IC23.1-64b 06/21/2023 09:20 (cpgbld16) $
-- on Mon Mar 30 20:55:45 2026


architecture structural of and2 is

begin

  output <= input2 and input1;

end structural;
