-- Created by @(#)$CDS: vhdlin version IC23.1-64b 06/21/2023 09:20 (cpgbld16) $
-- on Wed Apr  1 21:52:31 2026


library STD;
library IEEE;
use IEEE.std_logic_1164.all;

entity decoder2to4_auto is
  port (
    A1  : in  std_logic;
    A0  : in  std_logic;
    E   : in  std_logic;
    Y0  : out std_logic;
    Y1  : out std_logic;
    Y2  : out std_logic;
    Y3  : out std_logic
  );
end decoder2to4_auto;
