-- Created by @(#)$CDS: vhdlin version IC23.1-64b 06/21/2023 09:20 (cpgbld16) $
-- on Wed Apr  1 21:52:31 2026


architecture structural of decoder2to4_auto is

  component and2
    port (
      input1 : in  std_logic;
      input2 : in  std_logic;
      output : out std_logic);
  end component;

  component and3
    port (
      input1 : in  std_logic;
      input2 : in  std_logic;
      input3 : in  std_logic;
      output : out std_logic);
  end component;

  component inverter
    port (
      input  : in  std_logic;
      output : out std_logic);
  end component;

  for inv_A1   : inverter use entity work.inverter(structural);
  for inv_A0   : inverter use entity work.inverter(structural);
  for and3_0, and3_1, and3_2, and3_3 : and3 use entity work.and3(structural);

  signal A1_n : std_logic;
  signal A0_n : std_logic;

begin
  inv_A1 : inverter port map (input => A1, output => A1_n);
  inv_A0 : inverter port map (input => A0, output => A0_n);

  -- Y0 = E & ~A1 & ~A0
  and3_0 : and3 port map (input1 => E, input2 => A1_n, input3 => A0_n, output => Y0);
  -- Y1 = E & ~A1 & A0
  and3_1 : and3 port map (input1 => E, input2 => A1_n, input3 => A0,   output => Y1);
  -- Y2 = E & A1 & ~A0
  and3_2 : and3 port map (input1 => E, input2 => A1,   input3 => A0_n, output => Y2);
  -- Y3 = E & A1 & A0
  and3_3 : and3 port map (input1 => E, input2 => A1,   input3 => A0,   output => Y3);

end structural;
