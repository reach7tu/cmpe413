-- Created by @(#)$CDS: vhdlin version IC23.1-64b 06/21/2023 09:20 (cpgbld16) $
-- on Mon Mar 30 23:20:22 2026

library STD;
library IEEE;
use IEEE.std_logic_1164.all;

entity and3 is
  port (
    input1 : in  std_logic;
    input2 : in  std_logic;
    input3 : in  std_logic;
    output : out std_logic);
end and3;
