-- Created by @(#)$CDS: vhdlin version IC23.1-64b 06/21/2023 09:20 (cpgbld16) $
-- on Tue Mar 31 23:20:22 2026


architecture structural of and3 is
begin
  output <= input1 and input2 and input3;
end structural;
